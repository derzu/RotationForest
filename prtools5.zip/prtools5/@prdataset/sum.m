%SUM Dataset overload
