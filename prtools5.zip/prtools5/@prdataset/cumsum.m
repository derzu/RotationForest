%CUMSUM Dataset overload
