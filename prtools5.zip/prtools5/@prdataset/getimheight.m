%GETIMHEIGHT Get featsize, function oudated
%
% IMHEIGHT = GETIMHEIGHT(A)
%
% Returns feature size and prints warning.
% This routine is outdated, it should be replaced by GETFEATSIZE or
% GETOBJSIZE. It is assumed to be GETFEATSIZE for the moment.
