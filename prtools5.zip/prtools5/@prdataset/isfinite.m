%ISFINITE Dataset overload
