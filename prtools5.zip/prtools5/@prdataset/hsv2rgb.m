%HSV2RGB Dataset overload
%
%  B = HSV2RGB(A)
