%REPMAT Dummy, to create error
