%MEAN Datafile overload
