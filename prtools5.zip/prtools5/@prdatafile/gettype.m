%GETTYPE Get datafile TYPE field
%
%	   R = GETTYPE(A)
