%SETTYPE Set TYPE datafile field
