%LT Datafile overload
