%LDIVIDE Datafile overload
