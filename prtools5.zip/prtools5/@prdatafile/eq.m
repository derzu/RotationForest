%EQ Datafile overload
